//import 'dart:ffi';
import 'dart:math';
import 'package:flutter/material.dart';
import 'dart:async';

void main() {
  runApp(MaterialApp(
    home: NameEntryPage(),
  ));
}

// Define a StatelessWidget called NameEntryPage for entering the user's name
class NameEntryPage extends StatelessWidget {
  // Create a TextEditingController for the name input field
  final TextEditingController nameController = TextEditingController();

  // Override the build method to create the widget tree
  @override
  Widget build(BuildContext context) {
    // Return a Scaffold containing the main structure of the page
    return Scaffold(
      appBar: AppBar(
        title: Text("Enter Your Name"), // Set the title of the AppBar
      ),
      body: Container(
        // Set the background image for the container
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/background.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          // Center the Column's children along the main axis
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Add a Padding widget to display the game rules
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Game Rules:\n\n"
                "1. Each player starts with 100 dollars.\n"
                "2. Players take turns bidding on items.\n"
                "3. The highest bidder wins the item.\n"
                "4. Each round players will consume 1 water, 0.5 cloth or 1 fire, 0.5 meat or 1 bread.\n"
                "5. The player survive to the last is the winner.\n",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            // Add a Padding widget to create a TextField for the name input
            Padding(
              padding: EdgeInsets.all(8.0),
              child: TextField(
                controller: nameController, // Assign the TextEditingController
                decoration: InputDecoration(
                  labelText: "Enter your name:",
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            // Add an ElevatedButton for submitting the entered name
            ElevatedButton(
              onPressed: () async {
                String userName = nameController.text; // Get the entered name
                if (userName.isNotEmpty) {
                  // Navigate to the AuctionGame page if a name is entered
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AuctionGame(players: [
                        Player(userName, 150),
                        Player("Angela", 100),
                        Player("Tina", 100),
                        Player("Eric", 100)
                      ]),
                    ),
                  );
                } else {
                  // Show an AlertDialog if the name input is empty
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text("Error"),
                        content: Text("Please enter a name."),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text("OK"),
                          ),
                        ],
                      );
                    },
                  );
                }
              },
              child: Text("Submit"), // Set the button text
            ),
          ],
        ),
      ),
    );
  }
}

// Define a StatefulWidget called AuctionGame to manage the game state
class AuctionGame extends StatefulWidget {
  final List<Player> players;
  final TextEditingController bidController = TextEditingController();

  bool gameEnded = false;
  bool userWon = false;

  AuctionGame({required this.players});

  @override
  _AuctionGameState createState() => _AuctionGameState();
}

// Define a private State class called _AuctionGameState
class _AuctionGameState extends State<AuctionGame> {
  late GameLogic game;
  late Timer timer;
  int countdown = 30; // Set the initial countdown value, e.g., 30 seconds

  // Add this function to initialize the timer
  void startTimer() {
    timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (countdown == 0) {
        timer.cancel();
      } else {
        setState(() {
          countdown--;
        });
      }
    });
  }

  void resetTimer() {
    timer.cancel();
    countdown = 30;
    startTimer();
  }

  // Initialize the game state and timer when the widget is created
  @override
  void initState() {
    super.initState();
    game = GameLogic(players: widget.players, context: context);
    startTimer();
  }

  // Dispose of the timer when the widget is removed from the widget tree
  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  // Build the widget tree for the game page
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Auction Game"), // Set the title of the AppBar
      ),
      body: Container(
        // Set the background image for the container
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/background.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: ListView(
          padding: EdgeInsets.all(8.0),
          children: [
            // Display the current round number
            Center(
              child:
                  Text("Round ${game.round}", style: TextStyle(fontSize: 20)),
            ),
            SizedBox(height: 8),
            // Display the auction item
            Row(
              children: [
                Text("Auction Item: ", style: TextStyle(fontSize: 18)),
                // Display the appropriate icon for the auction item
                ...(game.itemToAuction == "Water"
                        ? [Icon(Icons.water_drop, color: Colors.lightBlue)]
                        : game.itemToAuction == "Meat"
                            ? [
                                Icon(Icons.kebab_dining,
                                    color: Color(0xffd2c176))
                              ]
                            : game.itemToAuction == "Bread"
                                ? [
                                    Icon(Icons.rice_bowl,
                                        color: Color(0xffbabab7))
                                  ]
                                : [
                                    Icon(Icons.local_fire_department,
                                        color: Color(0xffed3312))
                                  ])
                    .map((icon) => Padding(
                        padding: EdgeInsets.only(right: 8), child: icon))
                    .toList()
              ],
            ),
            // Display the remaining time for the auction
            Text("Time Remaining: $countdown seconds",
                style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            // Create a row with a TextField for the user to enter their bid
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text("Enter your bid:", style: TextStyle(fontSize: 18)),
                Container(
                  width: 100,
                  child: TextField(
                    controller: widget.bidController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 8),
            // Create a button for the user to submit their bid
            ElevatedButton(
              onPressed: () {
                int userBid = int.tryParse(widget.bidController.text) ?? 0;
                if (userBid <= widget.players[0].money) {
                  game.submitBid(userBid);
                  setState(() {});
                  resetTimer();
                } else {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text("Error"),
                        content: Text(
                            "Your bid cannot exceed your remaining money."),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text("OK"),
                          ),
                        ],
                      );
                    },
                  );
                }
              },
              child: Icon(
                Icons.attach_money,
                color: Colors.amber,
              ),
            ),
            SizedBox(height: 8),
            // Display the winner of the auction and their winning bid
            Text(
                "${game.winnerName} won the auction for ${game.itemWon} with a bid of ${game.highestBid}.",
                style: TextStyle(fontSize: 16)),
            SizedBox(height: 8),
            // Display all bids made during the auction
            Text("Bids:",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: game.bids.entries
                    .map(
                      (entry) => Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8.0),
                        child: Text("${entry.key}: ${entry.value}"),
                      ),
                    )
                    .toList(),
              ),
            ),
            SizedBox(height: 8),
            // Display the players' inventory
            Text("Inventory:",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ...widget.players.map((player) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("${player.name}:"),
                  Row(
                    children: [
                      Icon(Icons.water_drop,
                          color: Colors.lightBlue), // Water icon
                      Text(" ${player.items["Water"]}"),
                      SizedBox(width: 16),
                      Icon(Icons.kebab_dining,
                          color: Color(0xffd2c176)), // Meat icon
                      Text(" ${player.items["Meat"]}"),
                      SizedBox(width: 16),
                      Icon(Icons.rice_bowl,
                          color: Color(0xffbabab7)), // Bread icon
                      Text(" ${player.items["Bread"]}"),
                      SizedBox(width: 16),
                      Icon(Icons.bed,
                          color: Color(
                              0xff8276ec)), // Cloth icon (You can replace it with a custom icon)
                      Text(" ${player.items["Cloth"]}"),
                      SizedBox(width: 16),
                      Icon(Icons.local_fire_department,
                          color: Color(0xffed3312)), // Fire icon
                      Text(" ${player.items["Fire"]}"),
                    ],
                  ),
                ],
              );
            }),
            SizedBox(height: 16.0),
            // Display the players' remaining money
            Text("Remaining Money:",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ...widget.players.map((player) {
              return Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  // Dollar sign icon
                  Text("${player.name}: ", style: TextStyle(fontSize: 16)),
                  Icon(Icons.attach_money, color: Color(0xffd9a70f)),
                  Text("${player.money}", style: TextStyle(fontSize: 16)),
                ],
              );
            }),
          ],
        ),
      ),
    );
  }
}

class GameLogic {
  final List<Player> players;
  final BuildContext context; // Store the BuildContext for later use
  int round;
  String itemToAuction;
  String winnerName;
  int highestBid;
  String itemWon;
  Map<String, int> bids;

  // Constructor for initializing the game logic
  GameLogic({required this.players, required this.context})
      : round = 1,
        itemToAuction = "",
        winnerName = "",
        highestBid = 0,
        itemWon = "",
        bids = {} {
    startRound();
  }

  // Function to start a new round and choose a random item for auction
  void startRound() {
    itemToAuction =
        ["Water", "Meat", "Bread", "Cloth", "Fire"][Random().nextInt(5)];
    bids.clear();
  }

  // Function to add a specific amount of money to all players
  void addMoneyToAllPlayers(int amount) {
    for (var player in players) {
      player.money += amount;
    }
  }

  // Calculate the optimized robot bid based on other players' inventory and money
  int calculateRobotBid(Player player) {
    int baseBid = Random().nextInt(player.money + 1);

    // Initialize variables to store the player index and ratios for different resources
    int lowestWaterPlayer = -1;
    double lowestWaterRatio = double.infinity;
    int lowestClothFirePlayer = -1;
    double lowestClothFireRatio = double.infinity;
    int lowestMeatBreadPlayer = -1;
    double lowestMeatBreadRatio = double.infinity;

    // Loop through all players and calculate resource ratios
    for (int i = 0; i < players.length; i++) {
      if (players[i].isAlive() && players[i].name != player.name) {
        double waterRatio =
            players[i].items["Water"]! / players[i].money.toDouble();
        double clothFireRatio =
            (players[i].items["Cloth"]! + players[i].items["Fire"]!) /
                players[i].money.toDouble();
        double meatBreadRatio =
            (players[i].items["Meat"]! + players[i].items["Bread"]!) /
                players[i].money.toDouble();

        // Update the lowest resource ratios and their respective player indexes
        if (waterRatio < lowestWaterRatio) {
          lowestWaterRatio = waterRatio;
          lowestWaterPlayer = i;
        }
        if (clothFireRatio < lowestClothFireRatio) {
          lowestClothFireRatio = clothFireRatio;
          lowestClothFirePlayer = i;
        }
        if (meatBreadRatio < lowestMeatBreadRatio) {
          lowestMeatBreadRatio = meatBreadRatio;
          lowestMeatBreadPlayer = i;
        }
      }
    }

    // Initialize the minimum and maximum bid range based on the base bid
    int minBid = (baseBid * 0.3).round();
    int maxBid = baseBid;

    // Adjust the bid range based on the resource ratios and the item being auctioned
    if (itemToAuction == "Water" && lowestWaterPlayer != -1) {
      int bidIncrease = (lowestWaterRatio * baseBid * 0.5).round();
      minBid = (minBid + bidIncrease).clamp(0, player.money);
      maxBid = (maxBid + bidIncrease).clamp(0, player.money);
    } else if (itemToAuction == "Cloth" || itemToAuction == "Fire") {
      if (lowestClothFirePlayer != -1) {
        int bidIncrease = (lowestClothFireRatio * baseBid * 0.25).round();
        minBid = (minBid + bidIncrease).clamp(0, player.money);
        maxBid = (maxBid + bidIncrease).clamp(0, player.money);
      }
    } else if (itemToAuction == "Meat" || itemToAuction == "Bread") {
      if (lowestMeatBreadPlayer != -1) {
        int bidIncrease = (lowestMeatBreadRatio * baseBid * 0.25).round();
        minBid = (minBid + bidIncrease).clamp(0, player.money);
        maxBid = (maxBid + bidIncrease).clamp(0, player.money);
      }
    }
    // Set a random bid within the optimized range
    return Random().nextInt((maxBid - minBid + 1)) + minBid;
  }

  // Function to calculate a robot's bid based on its current resources
  int robotBid(Player robot) {
    int bid;
    double? currentResourceCount = robot.items[itemToAuction];
    double bidFraction = 0.2;
    // Determine the bid fraction based on the robot's current resource count
    if (currentResourceCount != null) {
      int currentResourceCountInt = currentResourceCount.toInt();
      if (currentResourceCountInt >= 3) {
        bidFraction = Random().nextDouble() / 3;
      } else if (currentResourceCountInt >= 2) {
        bidFraction = Random().nextDouble() / 2;
      } else {
        bidFraction = 0.5 + Random().nextDouble() / 2;
      }
    }

    // Calculate the bid based on the robot's money and the bid fraction
    bid = (robot.money * bidFraction).toInt();
    return bid;
  }

  // Function to handle the user's bid submission and execute auction logic
  void submitBid(int userBid) {
    round++;
    winnerName = "";
    highestBid = 0;
    itemWon = "";
    // Add the user's bid to the bids map
    bids[players[0].name] = userBid;

    // Perform the auction logic
    for (var player in players) {
      int bid = 0;
      if (player.isAlive()) {
        // Only consider bids from alive players
        if (player.name != players[0].name) {
          bid = robotBid(player);
        } else {
          bid = userBid;
        }
        bids[player.name] = bid;
        player.money -= bid;
        if (bid > highestBid) {
          highestBid = bid;
          winnerName = player.name;
          itemWon = itemToAuction;
        }
      }
    }

    // Update the winner and item won if the user's bid is the highest
    if (userBid > highestBid) {
      highestBid = userBid;
      winnerName = players[0].name;
      itemWon = itemToAuction;
    }

    // Update player inventories and money after the auction
    for (var player in players) {
      player.consume();
      if (player.name == winnerName) {
        player.addItem(itemWon);
      }
    }
    addMoneyToAllPlayers(10); // Add 10 dollars to all players after the round

    // Check if any player has died
    bool gameEnded = true;
    bool userWon = true;
    for (var player in players) {
      if (player.isAlive() && player.name != players[0].name) {
        // If any robot is alive, the game has not ended
        gameEnded = false;
      }
      if (!player.isAlive() && player.name == players[0].name) {
        // If the user is not alive, they lost
        userWon = false;
      }
    }
    // Show a popup window if the game has ended
    if (gameEnded) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Game Over"),
            content: Text(userWon ? "You won!" : "You lost!"),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text("OK"),
              ),
            ],
          );
        },
      );
    }
    startRound();
  }
}

// The Player class represents a player in the game, either the user or a robot.
class Player {
  final String name; // The name of the player
  int money; // The amount of money the player has
  Map<String, double>
      items; // A map representing the player's inventory of items

  // Constructor to initialize the player with a name, initial money, and random initial item quantities
  Player(this.name, this.money)
      : items = {
          "Water": Random().nextInt(5) +
              6, // Assign a random initial quantity of Water between 6 and 10
          "Meat": Random().nextInt(3) +
              1, // Assign a random initial quantity of Meat between 1 and 3
          "Bread": Random().nextInt(3) +
              3, // Assign a random initial quantity of Bread between 3 and 5
          "Cloth": Random().nextInt(3) +
              1, // Assign a random initial quantity of Cloth between 1 and 3
          "Fire": Random().nextInt(3) +
              3, // Assign a random initial quantity of Fire between 3 and 5
        };

  // Method to add an item to the player's inventory
  void addItem(String item) {
    items[item] = items[item]! + 1;
  }

  // Method to simulate the player consuming items each round
  void consume() {
    items["Water"] = max(0, items["Water"]! - 1); // Consume 1 unit of Water
    items["Meat"] = max(0, items["Meat"]! - 0.5); // Consume 0.5 units of Meat
    // If the player has no Meat, consume 1 unit of Bread instead
    if (items["Meat"]! <= 0) {
      items["Bread"] = max(0, items["Bread"]! - 1);
    }
    items["Cloth"] =
        max(0, items["Cloth"]! - 0.5); // Consume 0.5 units of Cloth
    // If the player has no Cloth, consume 1 unit of Fire instead
    if (items["Cloth"]! <= 0) {
      items["Fire"] = max(0, items["Fire"]! - 1);
    }
  }

  // Method to determine if the player is still alive in the game
  bool isAlive() {
    // A player is considered alive if they have:
    // 1. More than 0 units of Water
    // 2. More than 0 units of either Fire or Cloth
    // 3. More than 0 units of either Meat or Bread
    return items["Water"]! > 0 &&
        (items["Fire"]! > 0 || items["Cloth"]! > 0) &&
        (items["Meat"]! > 0 || items["Bread"]! > 0);
  }
}
