# Survival Auction Game

## Introduction
This project is a Survival Auction Game where the player competes against AI-driven robots in a resource management and bidding game. The goal is to survive as long as possible by managing resources such as water, food, and shelter while participating in auctions for essential items.

## Gameplay
Players begin the game with a starting amount of money and a random set of resources: water, meat, bread, cloth, and fire. In each round, an item is up for auction. Players must bid on the item to increase their resources. After each round, players consume some of their resources. The game continues until the user or all the robots have perished due to lack of resources.

## Rules
Each player starts with a random amount of resources and a set amount of money.
In each round, an item (water, meat, bread, cloth, or fire) is put up for auction.
Players submit their bids for the item. The highest bidder wins the item and adds it to their inventory. In case of a tie, the item is given to the player with the lowest quantity of that item.
After each round, players consume resources:
  1 unit of Water
  0.5 units of Meat; if no Meat, then 1 unit of Bread
  0.5 units of Cloth; if no Cloth, then 1 unit of Fire
Players who run out of water, food (meat or bread), and shelter (cloth or fire) will perish.
At the end of each round, every surviving player receives a fixed amount of money.
The game continues until the user or all the robots have perished.

## Installation
Clone this repository and run the project on your local machine. Make sure you have Flutter and Dart installed on your system.

## Running the Game
Run the project using your favorite IDE or by running the following command in the terminal:

arduino

## Copy code
flutter run

## Project Structure
main.dart: The entry point of the application.
game_screen.dart: Contains the game screen's layout and user interface.
game_logic.dart: Implements the game logic, auction mechanics, and player AI.
player.dart: Defines the Player class, which represents a player in the game.

## Contributing
If you'd like to contribute to this project, feel free to create a fork and submit a pull request. Any feedback, bug reports, or feature requests are welcome.
